<!-- jQuery 2.2.0 -->
<?php echo Html::script('backend/plugins/jQuery/jQuery-2.2.0.min.js'); ?>

<!-- jQuery UI 1.11.4 -->
<script src="https://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
	$.widget.bridge('uibutton', $.ui.button);
</script>

<!-- Bootstrap 3.3.6 -->
<?php echo Html::script('backend/bootstrap/js/bootstrap.min.js'); ?>

<?php echo Html::script('backend/js/bootstrap.file-input.js'); ?>


<!-- AdminLTE App -->
<?php echo Html::script('backend/dist/js/app.min.js'); ?>


<!-- DataTables -->
<?php echo Html::script('backend/plugins/datatables/jquery.dataTables.min.js'); ?>

<?php echo Html::script('backend/plugins/datatables/dataTables.bootstrap.min.js'); ?>


<!-- Fancybox -->
<?php echo Html::script('backend/js/jquery.fancybox.js'); ?>


<!-- Select2 -->
<?php echo Html::script('backend/plugins/select2/select2.full.min.js'); ?>


<!-- iCheck 1.0.1 -->
<?php echo Html::script('backend/plugins/iCheck/icheck.min.js'); ?>


<!-- Validator -->
<?php echo Html::script('vendor/jsvalidation/js/jsvalidation.js'); ?>


<!-- Override -->
<?php echo Html::script('backend/js/override.js'); ?>

