 
<?php $__env->startSection('title', 'Admin users'); ?> 
<?php $__env->startSection('content'); ?>
<div class="row">
		<div class="col-md-12">
			<!-- Body -->
			<div class="nav-tabs-custom margin">
				<ul class="nav nav-tabs">
					<li class="active"><a href="#tab1" data-toggle="tab">General</a></li>
				</ul>
					<div class="tab-content">
						<div class="tab-pane active" id="tab1">
							<?php echo Form::model($adminUser, array('files' => true, 'id' => 'editAdminUserForm', 'class' => 'panel-body form-horizontal')); ?>

							<div class="box-body">
								<div class="form-group">
									<?php echo Form::label('firstName', 'Nombre', array('class' => 'col-lg-2 col-sm-2 control-label')); ?>

									<div class="col-lg-8">
										<?php echo Form::text('firstName', $adminUser->firstName, array('class' => 'form-control')); ?>

										<span class="help-block help-block-error right-light"><?php echo $errors->first('firstName'); ?></span>
									</div>
								</div>
								<div class="form-group">
									<?php echo Form::label('lastName', 'Apellido', array('class' => 'col-lg-2 col-sm-2 control-label')); ?>

									<div class="col-lg-8">
										<?php echo Form::text('lastName', $adminUser->lastName, array('class' => 'form-control')); ?>

										<span class="help-block help-block-error right-light"><?php echo $errors->first('lastName'); ?></span>
									</div>
								</div>
								<div class="form-group">
									<?php echo Form::label('email', 'Correo electr&oacute;nico', array('class' => 'col-lg-2 col-sm-2 control-label')); ?>

									<div class="col-lg-8">
										<?php echo Form::text('email', $adminUser->email, array('class' => 'form-control')); ?>

										<span class="help-block help-block-error right-light"><?php echo $errors->first('email'); ?></span>
									</div>
								</div>
								<div class="form-group">
									<?php echo Form::label('phone', 'Tel&eacute;fono', array('class' => 'col-lg-2 col-sm-2 control-label')); ?>

									<div class="col-lg-8">
										<?php echo Form::text('phone', $adminUser->phone, array('class' => 'form-control')); ?>

										<span class="help-block help-block-error right-light"><?php echo $errors->first('phone'); ?></span>
									</div>
								</div>
								<div class="form-group">
									<?php echo Form::label('adminUserRoleId', 'Rol', array('class' => 'col-lg-2 col-sm-2 control-label')); ?>

									<div class="col-lg-8">
										<div>
											<?php echo Form::select('adminUserRoleId', $adminUserRoles, $adminUser->adminUserRole->id, array('class' => 'form-control select2')); ?>

										</div>
										<span class="help-block help-block-error right-light"><?php echo $errors->first('adminUserRoleId'); ?></span>
									</div>
								</div>
								<div class="form-group">
									<?php echo Form::label('enabled', 'Habilitado' , array('class' => 'col-lg-2 col-sm-2 control-label')); ?>

									<div class="col-lg-8">
										<div class="checkbox">
											<?php echo Form::checkbox('enabled', null, $adminUser->enabled, array('class' => 'minimal-red')); ?>

										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="box-body">
							<div class="form-group">
								<div class="col-lg-8 col-lg-offset-2">
									<?php echo Form::submit('Guardar', array('class' => 'btn btn-primary')); ?>

									<a href="<?php echo e(utf8_encode(route('management/admin-users/change-password', $adminUser->id))); ?>" class="btn btn-primary">Cambiar contraseña</a>
									<a href="<?php echo e(utf8_encode(route('management/admin-users'))); ?>" class="btn btn-default">Cancelar</a>
								</div>
							</div>
						</div>
				<?php echo Form::close(); ?>

			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_script'); ?>
<script type="text/javascript">

    $(document).ready(function() {
        // Styles to select
		$(".select2").select2();

		// Styles to checkbox
	    $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
			checkboxClass: 'icheckbox_minimal-red',
			radioClass: 'iradio_minimal-red'
	    });
    });
</script>
    <?php echo $editValidator; ?>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin.master.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>