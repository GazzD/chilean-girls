<div class="hidden-xs">
	<strong>Copyright &copy; 2017 Chilean Girls.</strong> Todos los derechos reservados.
</div>

