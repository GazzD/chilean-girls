<!DOCTYPE html>
<html lang="es">
<head>
	<?php echo $__env->make('templates.admin.master.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<meta charset="UTF-8">
</head>
<body class="hold-transition login-page">
	
	<?php echo $__env->yieldContent('content'); ?>
	
	<!-- SCRIPTS -->
	<?php echo $__env->make('templates.admin.master.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->yieldContent('custom_script'); ?>
</body>
</html>