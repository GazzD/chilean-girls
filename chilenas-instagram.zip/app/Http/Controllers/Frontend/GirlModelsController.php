<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\AppController;
use App\Models\GirlModel;

class GirlModelsController extends AppController
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
//         $this->middleware('auth');
    }
    
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($friendlyUrl)
    {
        // Find model by nickname
        $girlModel = GirlModel::with('galleries')
            ->with('videos')
            ->where('friendly_url', $friendlyUrl)
            ->first()
        ;
        if ($girlModel) {
            // Get instagram followers
            $raw = file_get_contents('https://www.instagram.com/'.$girlModel->instagram);
            preg_match('/\"followed_by\"\:\s?\{\"count\"\:\s?([0-9]+)/',$raw,$m);
            $girlModel->followersCount = intval($m[1]);
        }
        // Return view
        return $this->view('pages.frontend.girl-models.index')
            ->with('model', $girlModel)
        ;
    }
}
