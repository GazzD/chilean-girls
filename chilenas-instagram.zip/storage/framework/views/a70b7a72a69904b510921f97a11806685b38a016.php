<div class="wrapper">
    <div class="logotipo"> 
        <a href="<?php echo e(utf8_encode(route('home'))); ?>"><img src="<?php echo e(utf8_encode(asset('frontend/images/logo.png'))); ?>" style="max-height: 45px;" alt="ChileanGirls"></a>
    </div>
    <div class="menu_bar">
        <a class="bt-menu" style="cursor: pointer;"><span class="icon-menu"></span></a>
    </div>
    <nav>
        <ul>
            <li><a href="#">Modelos</a></li>
            <li class="submenu">
                <a href="#">Categor&iacute;as<span class="caret icon-chevron-small-down"></span></a>
                <ul class="children">
                    <li><a href="#">Profesional <span class="icon-dot-single"></span></a></li>
                    <li><a href="#">Amateur <span class="icon-dot-single"></span></a></li>
                    <li><a href="#">Cosplays <span class="icon-dot-single"></span></a></li>
                </ul>
            </li>
            <li><a href="#">Reg&iacute;strate</a></li>
            <li><a href="#">Ingresa</a></li>
        </ul>
    </nav>
</div>