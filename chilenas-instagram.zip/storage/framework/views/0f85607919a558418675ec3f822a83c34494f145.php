 
<?php $__env->startSection('title', 'Modelos'); ?> 
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <!-- Body -->
        <div class="nav-tabs-custom margin">
            <ul class="nav nav-tabs language-tabs">
                <li id="parent_tab1" class="active"><a href="#tab1" data-toggle="tab">General</a></li>
                <li class="pull-right"><a href="#" class="text-muted"><i class="fa fa-gear"></i></a></li>
            </ul>
            <?php echo Form::model($model, array('files' => true, 'id' => 'editGirlModelForm', 'class' => 'panel-body form-horizontal')); ?>

                <div class="tab-content">
                    <div class="tab-pane active" id="tab1">
                        <div class="box-body">
                            <div class="form-group">
                                <?php echo Form::label('nickname', 'Apodo', array('class' => 'col-lg-2 col-sm-2 control-label')); ?>

                                <div class="col-lg-8">
                                    <?php echo Form::text('nickname', null, array('id' => 'nickname', 'class' => 'form-control')); ?>

                                    <span class="help-block help-block-error right-light"><?php echo $errors->first('nickname'); ?></span>                                    
                                </div>
                            </div>
                            <div class="form-group">
                                <?php echo Form::label('instagram', 'Instagram', array('class' => 'col-lg-2 col-sm-2 control-label')); ?>

                                <div class="col-lg-8">
                                    <div class="input-group">
                                        <span class="input-group-addon">@</span>
                                        <?php echo Form::text('instagram', null, array('id' => 'instagram', 'class' => 'form-control')); ?>

                                    </div>
                                        <span class="help-block help-block-error right-light"><?php echo $errors->first('instagram'); ?></span>                                    
                                </div>
                            </div>
                            <div class="form-group">
                                <?php echo Form::label('summary', 'Resumen', array('class' => 'col-lg-2 col-sm-2 control-label')); ?>

                                <div class="col-lg-8">
                                    <?php echo Form::textArea('summary', null, array('id' => 'summary', 'class' => 'form-control', 'rows' => '3')); ?>

                                    <span class="help-block help-block-error right-light"><?php echo $errors->first('summary'); ?></span>                                    
                                </div>
                            </div>
                            <div class="form-group">
                            	<?php echo Form::label('profileImage', 'Foto de perfil', array('class' => 'col-lg-2 control-label')); ?>

                                <div class="col-lg-8">                                
                                    <img class="col-xs-6 col-md-4 col-sm-4 col-lg-4 responsive-img" src="<?php echo asset($model->profilePicture); ?>" style="border: 1px solid #ddd;"/>
                                </div>
                            </div>
                            <div class="form-group" class="file-height">
                                <span class="has-error"><?php echo $errors->first('profileImage]'); ?></span>
                                <div class="fileinput fileinput-new" data-provides="fileinput">
                                    <?php echo Form::label('profileImage', 'Cambiar imagen', array('class' => 'col-lg-2 col-sm-2 control-label')); ?>

                                    <div class="col-lg-8">
                                        <?php echo Form::file('profileImage', array('id' => 'profileImage', 'class' => 'file-upload', 'title' => 'Browse')); ?>

                                        <span class="right-light"><?php echo $errors->first('profileImage'); ?></span>        
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                            	<?php echo Form::label('promoPicture', 'Imagen promocional', array('class' => 'col-lg-2 control-label')); ?>

                                <div class="col-lg-8">                                
                                    <img class="col-xs-6 col-md-4 col-sm-4 col-lg-4 responsive-img" src="<?php echo asset($model->promoPicture); ?>" style="border: 1px solid #ddd;"/>
                                </div>
                            </div>
                            <div class="form-group" class="file-height">
                                <span class="has-error"><?php echo $errors->first('promoPicture]'); ?></span>
                                <div class="fileinput fileinput-new" data-provides="fileinput">
                                    <?php echo Form::label('promoPicture', 'Cambiar imagen', array('class' => 'col-lg-2 col-sm-2 control-label')); ?>

                                    <div class="col-lg-8">
                                        <?php echo Form::file('promoPicture', array('id' => 'promoPicture', 'class' => 'file-upload', 'title' => 'Browse')); ?>

                                        <span class="right-light"><?php echo $errors->first('promoPicture'); ?></span>        
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                            	<?php echo Form::label('promoVideo', 'Video promocional', array('class' => 'col-lg-2 control-label')); ?>

                                <div class="col-lg-8">
                                    <?php if($model->promoVideo): ?>
                                    <video class="col-xs-6 col-md-4 col-sm-4 col-lg-4 responsive-img product-img" controls controlsList="nodownload" style="border: 1px solid #ddd;">
                                        <source src="<?php echo asset($model->promoVideo); ?>" type="video/mp4">
                                        <source src="<?php echo asset($model->promoVideo); ?>" type='video/webm; codecs="vp8, vorbis"'/> 
                                        <source src="<?php echo asset($model->promoVideo); ?>" type='video/ogg; codecs="theora, vorbis"'>
                                        <source src="<?php echo asset($model->promoVideo); ?>" type='video/3gpp; codecs="mp4v.20.8, samr"'>
                                        Disculpe, no puede ver este video porque su navegador no soporta HTML5. 
                                    </video>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group" class="file-height">
                                <span class="has-error"><?php echo $errors->first('promoVideo]'); ?></span>
                                <div class="fileinput fileinput-new" data-provides="fileinput">
                                    <?php echo Form::label('promoVideo', 'Cambiar video', array('class' => 'col-lg-2 col-sm-2 control-label')); ?>

                                    <div class="col-lg-8">
                                        <?php echo Form::file('promoVideo', array('id' => 'promoVideo', 'class' => 'file-upload', 'title' => 'Browse')); ?>

                                        <span class="right-light"><?php echo $errors->first('promoVideo'); ?></span>        
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <?php echo Form::label('enabled', 'Habilitado' , array('class' => 'col-lg-2 col-sm-2 control-label')); ?>

                                <div class="col-lg-8">
                                    <div class="checkbox">
                                        <?php echo Form::checkbox('enabled', null, $model->enabled ,array('class' => 'minimal-red')); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="box-body">
                        <div class="form-group">
                            <div class="col-lg-8 col-lg-offset-2">
                                <?php echo Form::submit('Guardar', array('class' => 'btn btn-primary')); ?>

                                <a href="<?php echo route('management/models'); ?>" class="btn btn-default">Cancelar</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_script'); ?>
<script type="text/javascript">

    $(document).ready(function() {
        // Styles to select
        $(".select2").select2({
            minimumResultsForSearch: Infinity
        });
        
        // Styles to checkbox
        $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
            checkboxClass: 'icheckbox_minimal-red',
            radioClass: 'iradio_minimal-red'
        });
        
        // Styles to file upload
        $('input[type=file]').bootstrapFileInput();
        $('.file-inputs').bootstrapFileInput();
    });

    
</script>
<?php echo $validator; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin.master.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>