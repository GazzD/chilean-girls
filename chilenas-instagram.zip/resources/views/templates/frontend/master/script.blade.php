{!! Html::script('frontend/js/jquery-3.2.1.min.js') !!}
{!! Html::script('vendor/jsvalidation/js/jsvalidation.js') !!}
{!! Html::script('frontend/js/menubar.js') !!}
{!! Html::script('frontend/js/prefixfree.min.js') !!}
<!-- {!! Html::script('frontend/js/datepicker.min.js') !!} -->
{!! Html::script('frontend/js/main.js') !!}