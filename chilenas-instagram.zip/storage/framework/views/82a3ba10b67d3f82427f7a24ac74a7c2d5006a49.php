 
<?php $__env->startSection('title', 'Account'); ?> 
<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <div class="box box-danger">
                <!-- Body -->
                <?php echo Form::model($adminUser, array('id' => 'changePasswordForm', 'class' => 'panel-body form-horizontal')); ?>

                <div class="box-body">
                    <div class="tab-pane active" id="tab1">
                        <div class="box-body">
                            <div class="form-group">
                                <?php echo Form::label('password', 'Nueva contraseña', array('class' => 'col-lg-2 col-sm-2 control-label')); ?>

                                <div class="col-lg-8">
                                    <?php echo Form::password('password', array('id' => 'password', 'class'=>'form-control')); ?>

                                    <span class="help-block help-block-error right-light"><?php echo $errors->first('password'); ?></span>
                                </div>
                            </div>    
                            <div class="form-group">
                                <?php echo Form::label('passwordConfirmation', 'Confirmación de contraseña', array('class' => 'col-lg-2 col-sm-2 control-label')); ?>

                                <div class="col-lg-8">
                                    <?php echo Form::password('passwordConfirmation', array('id' => 'passwordConfirmation', 'class'=>'form-control')); ?>

                                    <span class="help-block help-block-error right-light"><?php echo $errors->first('passwordConfirmation'); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="box-body">
                            <div class="form-group">
                                <div class="col-lg-8 col-lg-offset-2">
                                    <?php echo Form::submit('Guardar', array('class' => 'btn btn-primary')); ?>

                                    <a href="<?php echo route('account'); ?>" class="btn btn-default">Cancelar</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom_script'); ?>
    <?php echo $validator; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin.master.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>