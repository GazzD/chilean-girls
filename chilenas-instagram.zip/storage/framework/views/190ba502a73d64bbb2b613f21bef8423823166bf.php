<?php echo Html::script('frontend/js/jquery-3.2.1.min.js'); ?>

<?php echo Html::script('vendor/jsvalidation/js/jsvalidation.js'); ?>

<?php echo Html::script('frontend/js/menubar.js'); ?>

<?php echo Html::script('frontend/js/prefixfree.min.js'); ?>

<!-- <?php echo Html::script('frontend/js/datepicker.min.js'); ?> -->
<?php echo Html::script('frontend/js/main.js'); ?>