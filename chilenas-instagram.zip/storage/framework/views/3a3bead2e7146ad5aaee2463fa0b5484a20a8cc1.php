<?php $__env->startSection('title'); ?> Modelos -   
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="wrapper5">
        <div class="perfil">
            <img style="float:left;" src="<?php echo e(utf8_encode(asset($model->profilePicture))); ?>" alt="<?php echo $model->nickname; ?>}">
            <div class="nombre">
                <h5 style="text-transform: uppercase;"><?php echo $model->nickname; ?></h5>
                <h6><?php echo $model->summary; ?></h6>
                <div class="barrasocial">
                    <ul>
                        <li><a href="https://instagram.com/<?php echo $model->instagram; ?>" target="_blank" class="icon-instagram"></a></li>
                        <li><a class="texto">Seguidores: <?php echo $model->followersCount; ?></a></li>
                        <li><a class="texto">Compartir en</a></li>
                        <li><a href="#" class="icon-facebook"></a></li>
                        <li><a href="#" class="icon-twitter"></a></li>
                    </ul>
                </div>
                <?php if($model->promoVideo): ?>
                    <div style="text-align: center; padding-top: 2em;">
                        <video id="promoVideo" class="" controls controlsList="nodownload" width="300" style="border: 1px solid #ddd;">
                            <source src="<?php echo asset($model->promoVideo); ?>" type="video/mp4">
                            <source src="<?php echo asset($model->promoVideo); ?>" type='video/webm; codecs="vp8, vorbis"'/> 
                            <source src="<?php echo asset($model->promoVideo); ?>" type='video/ogg; codecs="theora, vorbis"'>
                            <source src="<?php echo asset($model->promoVideo); ?>" type='video/3gpp; codecs="mp4v.20.8, samr"'>
                            Disculpe, no puede ver este video porque su navegador no soporta HTML5. 
                        </video>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php if($model->galleries->count()>0 || $model->videos->count()>0): ?>
    <section id="banner3">
        <nav>
            <ul>
                <li style="cursor: pointer;"><a>FOTOS</a></li>
                <li style="cursor: pointer;"><a>VIDEOS</a></li>
            </ul>
        </nav>
    </section>
    <div class="main2">
        <ul class="list-imag">
            <?php $__currentLoopData = $model->galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="#"><img src="<?php echo e(utf8_encode(asset($gallery->mainImage))); ?>" alt="<?php echo $gallery->name; ?>" class="image"></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom_script'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            // Block video to be downloaded
            $('#promoVideo').bind('contextmenu',function() { return false; });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.frontend.master.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>