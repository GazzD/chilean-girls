<!-- Logo -->
<a href="<?php echo e(utf8_encode(route('admin'))); ?>" class="logo"> <!-- mini logo for sidebar mini 50x50 pixels -->
	<span class="logo-mini"><img alt="Chilean Girls" src="<?php echo e(utf8_encode(asset('backend/images/gota.png'))); ?>"></span> <!-- logo for regular state and mobile devices -->
	<span class="logo-lg"><img alt="Chilean Girls" src="<?php echo e(utf8_encode(asset('backend/images/logo.png'))); ?>"></span>
</a>
<!-- Header Navbar: style can be found in header.less -->
<nav class="navbar navbar-static-top">
	<!-- Sidebar toggle button-->
	<a href="#" class="sidebar-toggle" data-toggle="offcanvas"
		role="button"> <span class="sr-only">Toggle navigation</span>
	</a>

	<div class="navbar-custom-menu">
		<ul class="nav navbar-nav">
			<!-- User Account: style can be found in dropdown.less -->
			<li class="dropdown user user-menu">
				<a href="#" class="dropdown-toggle" data-toggle="dropdown"> 
					<img src="<?php echo asset('backend/images/avatar.jpg'); ?>" class="user-image" alt="User Image">
					<span class="hidden-xs"><?php echo e(utf8_encode(Session::get('admin.auth.admin-user.firstName'))); ?> <?php echo e(utf8_encode(Session::get('admin.auth.admin-user.lastName'))); ?></span>
				</a>
				<ul class="dropdown-menu">
					<!-- User image -->
					<li class="user-header">
						<img src="<?php echo asset('backend/images/avatar.jpg'); ?>" class="img-circle" alt="User Image">
						<p>
							<?php echo e(utf8_encode(Session::get('admin.auth.admin-user.firstName'))); ?> <?php echo e(utf8_encode(Session::get('admin.auth.admin-user.lastName'))); ?><small><?php echo e(utf8_encode(Session::get('admin.auth.admin-user.email'))); ?></small>
						</p>
					</li>
					<!-- Menu Footer-->
					<li class="user-footer">
						<div class="pull-left">
							<a href="<?php echo e(utf8_encode(route('account'))); ?>" class="btn btn-default btn-flat">Cuenta</a>
						</div>
						<div class="pull-right">
							<a href="<?php echo e(utf8_encode(route('logout'))); ?>" class="btn btn-default btn-flat">Cerrar sesi&oacute;n</a>
						</div>
					</li>
				</ul>
			</li>
		</ul>
	</div>
</nav>