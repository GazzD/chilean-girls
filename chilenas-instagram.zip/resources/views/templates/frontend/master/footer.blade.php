<div class="info">
    Todas las participantes del sitio han declarado ser mayores de edad
</div>
<div class="menufooter">
    <nav>
        <ul>    
            <li><a href="{{route('contact')}}">Cont&aacute;ctanos</a></li>
            <li><a href="#">Preguntas Frecuentes</a></li>
            <li><a href="#">T&eacute;rminos y Condiciones</a></li>    
        </ul>
    </nav>
</div>
