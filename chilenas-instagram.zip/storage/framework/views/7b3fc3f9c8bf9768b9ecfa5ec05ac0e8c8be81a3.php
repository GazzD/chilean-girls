 
<?php $__env->startSection('title', 'Modelos'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <!-- Body -->
        <div class="nav-tabs-custom margin">
            <ul class="nav nav-tabs">
                <li class="active"><a href="#tab1" data-toggle="tab">General</a></li>
            </ul>
            <?php echo Form::model($video, array('class'=>'form-horizontal panel-body','id' => 'detail-video-form')); ?>

                <div class="tab-content">
                    <div class="tab-pane active" id="tab1">
                        <div class="box-body">
                            <div class="form-group">
                                <?php echo Form::label('name', 'Nombre', array('class' => 'col-lg-2 col-sm-2 control-label')); ?>

                                <div class="col-lg-8">
                                    <?php echo Form::text('name', null, array('id' => 'name', 'class' => 'form-control', 'disabled')); ?>

                                </div>
                            </div>
                            <div class="form-group">
                                <?php echo Form::label('model', 'Modelo', array('class' => 'col-lg-2 col-sm-2 control-label')); ?>

                                <div class="col-lg-8">
                                    <div>
                                        <?php echo Form::text('model', $video->model->nickname, array('id' => 'name', 'class' => 'form-control', 'disabled')); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <?php echo Form::label('price', 'Precio', array('class' => 'col-lg-2 col-sm-2 control-label')); ?>

                                <div class="col-lg-8">
                                    <?php echo Form::text('price', null, array('id' => 'price', 'class' => 'form-control', 'disabled')); ?>

                                    <span class="help-block help-block-error right-light"><?php echo $errors->first('price'); ?></span>
                                </div>
                            </div>
                            <div class="form-group">
                                <?php echo Form::label('category', 'Categoría', array('class' => 'col-lg-2 col-sm-2 control-label')); ?>

                                <div class="col-lg-8">
                                    <div>
                                        <?php echo Form::text('category', $video->category->name,array('class' => 'form-control select2', 'disabled')); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <?php echo Form::label('summary', 'Descripción', array('class' => 'col-lg-2 col-sm-2 control-label')); ?>

                                <div class="col-lg-8">
                                    <?php echo Form::textArea('summary', null, array('id' => 'summary', 'class' => 'form-control', 'rows' => '3', 'disabled')); ?>

                                    <span class="help-block help-block-error right-light"><?php echo $errors->first('summary'); ?></span>
                                </div>
                            </div>
                            <div class="form-group">
                                <?php echo Form::label(null, 'Video', array('class'=>'col-lg-2 col-sm-2 control-label')); ?> 
                                <div class="col-lg-8">                                
                                    <video class="col-xs-6 col-md-4 col-sm-4 col-lg-4 responsive-img product-img" controls controlsList="nodownload" style="border: 1px solid #ddd;">
                                        <source src="<?php echo asset($video->video); ?>" type="video/mp4">
                                        <source src="<?php echo asset($video->video); ?>" type='video/webm; codecs="vp8, vorbis"'/> 
                                        <source src="<?php echo asset($video->video); ?>" type='video/ogg; codecs="theora, vorbis"'>
                                        <source src="<?php echo asset($video->video); ?>" type='video/3gpp; codecs="mp4v.20.8, samr"'>
                                        Disculpe, no puede ver este video porque su navegador no soporta HTML5. 
                                    </video>
                                </div>
                            </div>
                            <div class="form-group">
                                <?php echo Form::label(null, 'Habilitado', array('class'=>'col-lg-2 col-sm-2 control-label')); ?> 
                                <div class="col-lg-8">
                                    <div class="checkbox">
                                    <?php echo Form::checkbox('enabled', '', null, array('class' => 'minimal-red','disabled' => true)); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                
                    <div class="box-body">
                        <div class="form-group">
                            <div class="col-lg-2 col-sm-2"></div>
                            <div class="col-lg-8">
                                <a href="<?php echo route('management/videos/edit', $video->id); ?>" class="btn btn-primary">Editar</a>
                                <a class="btn btn-default" href="<?php echo route('management/videos'); ?>">Volver</a>                    
                            </div>
                        </div>
                    </div>
                </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom_script'); ?>

    <?php echo Html::script('frontend/js/collapse/simple-expand.min.js'); ?>

    <?php echo Html::script('frontend/js/jquery.magnific-popup.js'); ?>

    
    <script type="text/javascript">
    
        $(document).ready(function() {
    
            // Styles to checkbox
            $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
                checkboxClass: 'icheckbox_minimal-red',
                radioClass: 'iradio_minimal-red'
            });

            $('#single_image').on('click',function() {
               $(this).attr('title','<a href="'+ '<?php echo asset($video->profilePicture); ?>" download> <i class="fa fa-download"></i> Descarga</a>' );
                $('#single_image').fancybox({
                    helpers : {
                        title: {
                            type: 'inside'
                        }
                    },
                });
            });
                
        });
    
        
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin.master.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>