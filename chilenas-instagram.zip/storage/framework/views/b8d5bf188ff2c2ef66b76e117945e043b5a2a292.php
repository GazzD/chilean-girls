 
<?php $__env->startSection('title', 'Account'); ?> 
<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <div class="box box-danger">
                <!-- Body -->
                <?php echo Form::model($adminUser, array('id' => 'settingsForm', 'class' => 'panel-body form-horizontal')); ?>

                <div class="box-body">
                    <div class="form-group">
                        <?php echo Form::label('firstName', 'Nombre', array('class' => 'col-lg-2 col-sm-2 control-label')); ?>

                        <div class="col-lg-8">
                            <?php echo Form::text('firstName', null, array('id' => 'firstName', 'class' => 'form-control', 'disabled')); ?>

                            <span class="help-block help-block-error right-light"><?php echo $errors->first('firstName'); ?></span>
                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('lastName', 'Apellido', array('class' => 'col-lg-2 col-sm-2 control-label')); ?>

                        <div class="col-lg-8">
                            <?php echo Form::text('lastName', null, array('id' => 'lastName', 'class' => 'form-control', 'disabled')); ?>

                            <span class="help-block help-block-error right-light"><?php echo $errors->first('lastName'); ?></span>
                        </div>
                    </div>            
                    <div class="form-group">
                        <?php echo Form::label('email', 'Correo electrónico', array('class' => 'col-lg-2 col-sm-2 control-label')); ?>

                        <div class="col-lg-8">
                            <?php echo Form::text('email', null, array('id' => 'email', 'class' => 'form-control', 'disabled')); ?>

                            <span class="help-block help-block-error right-light"><?php echo $errors->first('email'); ?></span>
                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('phone', 'Teléfono', array('class' => 'col-lg-2 col-sm-2 control-label')); ?>

                        <div class="col-lg-8">
                            <?php echo Form::text('phone', null, array('id' => 'phone', 'class' => 'form-control', 'disabled')); ?>

                            <span class="help-block help-block-error right-light"><?php echo $errors->first('phone'); ?></span>
                        </div>
                    </div>
                </div>
                <div class="box-body">
                    <div class="form-group">
                        <div class="col-lg-8 col-lg-offset-2">
                            <a class="btn btn-primary" href="<?php echo route('account/change-password'); ?>">Cambiar contraseña</a>
                            <a href="<?php echo route('admin'); ?>" class="btn btn-default">Cancelar</a>
                        </div>
                    </div>
                </div>
                <?php echo Form::close(); ?>

            </div>        
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_script'); ?>
<?php echo $validator; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin.master.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>