 <?php $__env->startSection('title', 'Admin Users'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<!-- Body -->
		<div class="nav-tabs-custom margin">
			<ul class="nav nav-tabs">
				<li class="active"><a href="#tab1" data-toggle="tab">General</a></li>
			</ul>
			<?php echo Form::model($adminUser, array('class'=>'form-horizontal panel-body','id' => 'detail-admin-users-form')); ?>

				<div class="tab-content">
					<div class="tab-pane active" id="tab1">
						<div class="box-body">
							<div class="form-group">
								<?php echo Form::label(null, 'Nombre', array('class'=>'col-lg-2 col-sm-2 control-label')); ?> 
								<div class="col-lg-8">
								 	<?php echo Form::text('firstName', null, array('class'=>'form-control', 'id' => 'firstName', 'disabled')); ?>

								</div>
							</div>
							<div class="form-group">
								<?php echo Form::label(null, 'Apellido', array('class'=>'col-lg-2 col-sm-2 control-label')); ?>  
								<div class="col-lg-8">
								 	<?php echo Form::text('lastName', null, array('class'=>'form-control', 'id' => 'lastName', 'disabled')); ?>

								</div>
							</div>
							<div class="form-group">
								<?php echo Form::label(null, 'Correo electr&oacute;nico', array('class'=>'col-lg-2 col-sm-2 control-label')); ?> 
								<div class="col-lg-8">
								 	<?php echo Form::text('email', null, array('class'=>'form-control', 'id' => 'email', 'disabled')); ?>

								</div>
							</div>
							<div class="form-group">
								<?php echo Form::label(null, 'Tel&eacute;fono', array('class'=>'col-lg-2 col-sm-2 control-label')); ?> 
								<div class="col-lg-8">
								 	<?php echo Form::text('phone', null, array('class'=>'form-control', 'id' => 'phone', 'disabled')); ?>

								</div>
							</div>
							<div class="form-group">
								<?php echo Form::label(null, 'Rol', array('class'=>'col-lg-2 col-sm-2 control-label')); ?> 
								<div class="col-lg-8">
							 	<?php echo Form::text('adminUserRole', $adminUser->adminUserRole->name, array('class'=>'form-control', 'id' => 'role', 'disabled')); ?>

								</div>
							</div>
							<div class="form-group">
								<?php echo Form::label(null, 'Habilidado', array('class'=>'col-lg-2 col-sm-2 control-label')); ?> 
								<div class="col-lg-8">
									<div class="checkbox">
								 		<?php echo Form::checkbox('enabled', '', null, array('disabled' => true, 'class' => 'minimal-red')); ?>

								 	</div>
								</div>
							</div>
						</div>
					</div>
					<div class="box-body">
						<div class="form-group">
							<div class="col-lg-8 col-lg-offset-2">
								<a  href="<?php echo route('management/admin-users/edit', $adminUser->id); ?>" class="btn btn-primary">Editar</i></a>
								<a class="btn btn-default" href="<?php echo route('management/admin-users'); ?>">Volver</a>					
							</div>
						</div>
					</div>
				</div>
			<?php echo Form::close(); ?>

		</div>
	</div>
</div>
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('custom_script'); ?>
<script type="text/javascript">
$(document).ready(function() {

	// Styles to checkbox
    $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
		checkboxClass: 'icheckbox_minimal-red',
		radioClass: 'iradio_minimal-red'
    });
});

</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('templates.admin.master.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>