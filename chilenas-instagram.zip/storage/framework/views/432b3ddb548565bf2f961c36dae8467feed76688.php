<!DOCTYPE html>
<html>
<head>
	<?php echo $__env->make('templates.admin.master.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body class="hold-transition skin-purple sidebar-mini">
	<div class="wrapper">
		<header class="main-header">
			<?php echo $__env->make('templates.admin.master.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	  	</header>
		<!-- Left side column. contains the logo and sidebar -->
		<aside class="main-sidebar">
			<?php echo $__env->make('templates.admin.master.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</aside>
	
	  	<!-- Content Wrapper. Contains page content -->
		<div class="content-wrapper">
			<?php echo $__env->make('templates.admin.master.breadcrumbs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->yieldContent('content'); ?>
		</div>
	  	<!-- /.content-wrapper -->
		<footer class="main-footer">
			<?php echo $__env->make('templates.admin.master.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>	
		</footer>
	</div>
	<!-- ./wrapper -->
	<!-- SCRIPTS -->
	<?php echo $__env->make('templates.admin.master.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->yieldContent('custom_script'); ?>
	<script type="text/javascript">
		$(document).ready(function(){
			var validator = $('form').validate();
			$('select').change(function(){
				validator.element($(this));
			});
			$('input').change(function(){
				validator.element($(this));
			});
			$('textarea').change(function(){
				validator.element($(this));
			});
		});
	</script>
</body>
</html>
