<!-- META TAGS -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
<meta name="description" content="">
<meta name="keywords" content="">
<!-- TITLE -->
<title>Chilenas de Instagram - <?php echo $__env->yieldContent('title'); ?></title>

<!-- FONTS-->
<?php echo Html::style('frontend/fonts/fonts.css'); ?>


<!-- CSS -->
<!-- <?php echo Html::style('frontend/css/datepicker.min.css'); ?> -->
<?php echo Html::style('frontend/css/style.css'); ?>

<?php echo Html::style('frontend/css/override.css'); ?>