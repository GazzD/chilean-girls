<!DOCTYPE html>
<html>
    <head>
        <?php echo $__env->make('templates.frontend.master.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </head>
    <body>
        <div class="contenedor">
            <header>
                <?php echo $__env->make('templates.frontend.master.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </header>
            
            <?php echo $__env->yieldContent('content'); ?>
            <section id="banner2">
                <h2>¿Quieres formar parte de las modelos? contactanos o escribe un mail a postulacion@chileangirls.cl</h2>
            </section>
            <div class="pago">
                 M&eacute;todos de Pago.
                 <img src="<?php echo e(utf8_encode(asset('frontend/images/webpay.png'))); ?>">
            </div>
            <footer>
                <?php echo $__env->make('templates.frontend.master.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </footer>
        </div>
        <!-- SCRIPTS -->
        <?php echo $__env->make('templates.frontend.master.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('custom_script'); ?>
    </body>
</html>