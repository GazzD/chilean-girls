<?php $__env->startSection('title'); ?>
    Inicio
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <div class="slideshow">
            <ul class="slider">
            	<?php $__currentLoopData = $carouselItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carouselItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                	<li><a href="<?php echo e(utf8_encode($carouselItem->link)); ?>" target="<?php echo e(utf8_encode($carouselItem->target)); ?>"><img src="<?php echo e(utf8_encode(asset($carouselItem->image))); ?>" alt="<?php echo $carouselItem->name; ?>"></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <ol class="pagination">
            </ol>
            <div class="left">
                <span class="icon-chevron-thin-left"></span>
            </div>
            <div class="right">
                <span class="icon-chevron-thin-right"></span>
            </div>    
        </div>
    </div>
    
    <section id="banner">
        <h2>Conoce a las chilenas mas sensuales y seguidas de instagram</h2>
    </section>
    
    <div class="main">
        <ul class="list-imag">
            <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo route('models', $model->friendlyUrl); ?>"><img src="<?php echo e(utf8_encode(asset($model->promoPicture))); ?>" alt="" class="image"></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.frontend.master.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>