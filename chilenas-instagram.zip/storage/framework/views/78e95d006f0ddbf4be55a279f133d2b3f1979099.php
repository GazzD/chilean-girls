<?php $__env->startSection('title', trans('frontend/sections.sign-in')); ?>

<?php $__env->startSection('content'); ?>	 

<div class="login-box">
  <div class="login-logo">
    <a href="<?php echo e(route('admin')); ?>"><img src="<?php echo asset('backend/images/logo.png'); ?>"></a>
  </div>
	<div class="login-box-body">
		<p class="login-box-msg">Iniciar sesi&oacute;n</p>
		<?php echo Form::open(array('route' => 'sign-in/authenticate', 'id' => 'sign-in-form')); ?>

			<div class="form-group has-feedback">
				<?php echo Form::text('email', null, array('id' => 'email', 'class' => 'form-control', 'placeholder' => 'Email')); ?>

				<span class="glyphicon glyphicon-envelope form-control-feedback"></span>
				<span class="error-help-block"><?php echo e($errors->first('email')); ?></span>
			</div>
			
			<div class="form-group has-feedback">
				<?php echo Form::password('password', array('id' => 'password', 'class' => 'form-control', 'placeholder' => 'Password')); ?>

				<span class="glyphicon glyphicon-lock form-control-feedback"></span>
			</div>
			
			<?php if(session()->has('error-message')): ?>
				<div class="row">
					<div class="col-xs-12">
						<div class="alert alert-danger">
							<p><?php echo e(session('error-message')); ?></p>
						</div>
					</div>
				</div>
			<?php endif; ?>
			
			<div class="row">
				<div class="col-xs-8">
					<div class="checkbox icheck">
						<label>
							<a href="<?php echo e(route('password-recovery')); ?>">Olvid&eacute; mi contrase&ntilde;a</a><br>
						</label>
					</div>
				</div>
				
				<div class="col-xs-4">
					<button type="submit" class="btn btn-primary btn-block btn-flat">Enviar</button>
				</div>
			</div>
		<?php echo Form::close(); ?>

	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_script'); ?>
	<?php echo $validator; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin.public.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>