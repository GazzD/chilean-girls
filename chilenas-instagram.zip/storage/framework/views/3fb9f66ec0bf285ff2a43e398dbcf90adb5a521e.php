 
<?php $__env->startSection('title', 'Modelos'); ?> 
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <!-- Body -->
        <div class="nav-tabs-custom margin">
            <ul class="nav nav-tabs language-tabs">
                <li id="parent_tab1" class="active"><a href="#tab1" data-toggle="tab">General</a></li>
                <li class="pull-right"><a href="#" class="text-muted"><i class="fa fa-gear"></i></a></li>
            </ul>
            <?php echo Form::model($video, array('files' => true, 'id' => 'addVideoForm', 'class' => 'panel-body form-horizontal')); ?>

                <div class="tab-content">
                    <div class="tab-pane active" id="tab1">
                        <div class="box-body">
                            <div class="form-group">
                                <?php echo Form::label('name', 'Nombre', array('class' => 'col-lg-2 col-sm-2 control-label')); ?>

                                <div class="col-lg-8">
                                    <?php echo Form::text('name', '', array('id' => 'name', 'class' => 'form-control')); ?>

                                    <span class="help-block help-block-error right-light"><?php echo $errors->first('name'); ?></span>
                                </div>
                            </div>
                            <div class="form-group">
                                <?php echo Form::label('model', 'Modelo', array('class' => 'col-lg-2 col-sm-2 control-label')); ?>

                                <div class="col-lg-8">
                                    <div>
                                        <?php echo Form::select('model', $models, null ,array('class' => 'form-control select2', 'placeholder' => 'Selecciona una opci&oacute;n', 'style' => 'width:100% !important;')); ?>

                                    </div>
                                    <span class="help-block help-block-error right-light"><?php echo $errors->first('model'); ?></span>
                                </div>
                            </div>
                            <div class="form-group">
                                <?php echo Form::label('price', 'Precio', array('class' => 'col-lg-2 col-sm-2 control-label')); ?>

                                <div class="col-lg-8">
                                    <?php echo Form::text('price', '', array('id' => 'price', 'class' => 'form-control')); ?>

                                    <span class="help-block help-block-error right-light"><?php echo $errors->first('price'); ?></span>
                                </div>
                            </div>
                            <div class="form-group">
                                <?php echo Form::label('categoryId', 'Categoría', array('class' => 'col-lg-2 col-sm-2 control-label')); ?>

                                <div class="col-lg-8">
                                    <div>
                                        <?php echo Form::select('categoryId', $categories, null ,array('class' => 'form-control select2', 'placeholder' => 'Selecciona una opci&oacute;n', 'style' => 'width:100% !important;')); ?>

                                    </div>
                                    <span class="help-block help-block-error right-light"><?php echo $errors->first('categoryId'); ?></span>
                                </div>
                            </div>
                            <div class="form-group">
                                <?php echo Form::label('summary', 'Descripción', array('class' => 'col-lg-2 col-sm-2 control-label')); ?>

                                <div class="col-lg-8">
                                    <?php echo Form::textArea('summary', '', array('id' => 'summary', 'class' => 'form-control', 'rows' => '3')); ?>

                                    <span class="help-block help-block-error right-light"><?php echo $errors->first('summary'); ?></span>
                                </div>
                            </div>
                            <div class="form-group" class="file-height">
                                <div class="fileinput fileinput-new" data-provides="fileinput">
                                    <?php echo Form::label('video', 'Video', array('class' => 'col-lg-2 col-sm-2 control-label')); ?>

                                    <div class="col-lg-8">
                                        <?php echo Form::file('video', array('id' => 'video', 'class' => 'file-upload', 'title' => 'Browse')); ?>

                                        <span class="right-light"><?php echo $errors->first('video'); ?></span>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <?php echo Form::label('enabled', 'Habilitado' , array('class' => 'col-lg-2 col-sm-2 control-label')); ?>

                                <div class="col-lg-8">
                                    <?php echo Form::checkbox('enabled', null, '' ,array('class' => 'minimal-red')); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="box-body">
                        <div class="form-group">
                            <div class="col-lg-8 col-lg-offset-2">
                                <?php echo Form::submit('Guardar', array('class' => 'btn btn-primary')); ?>

                                <a href="<?php echo route('management/models'); ?>" class="btn btn-default">Cancelar</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_script'); ?>
<script type="text/javascript">

    $(document).ready(function() {
    	// Styles to select
        $(".select2").select2({});

        // Styles to checkbox
        $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
            checkboxClass: 'icheckbox_minimal-red',
            radioClass: 'iradio_minimal-red'
        });
        // Styles to file upload
        $('input[type=file]').bootstrapFileInput();
        $('.file-inputs').bootstrapFileInput();
        
    });
</script>
<?php echo $validator; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin.master.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>