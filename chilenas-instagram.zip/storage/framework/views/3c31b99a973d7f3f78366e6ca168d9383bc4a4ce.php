<?php if(isset($breadcrumbs)): ?>
<!-- Breadcrumbs -->
<section class="content-header">
	<h1>
		<?php echo isset($title)?$title:''; ?> <small><?php echo isset($subtitle)?$subtitle:''; ?></small>
	</h1>
	<ol class="breadcrumb">
		<li><a href="<?php echo route('admin'); ?>"><i class="fa fa-home"></i> Home</a></li>
		<?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li><a href="<?php echo $breadcrumb->url; ?>"><i class="<?php echo $breadcrumb->icon; ?>"></i><?php echo $breadcrumb->title; ?></a></li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ol>
</section>
<?php endif; ?>
